import React, { useState } from 'react';
import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm';
import ChangePasswordForm from './components/ChangePasswordForm';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import ProductList from './components/ProductList';
import { MaterialIcons } from '@expo/vector-icons'; 

const Tab = createBottomTabNavigator();

const App = () => {
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [showRegisterForm, setShowRegisterForm] = useState(false);
  const [showChangePasswordForm, setShowChangePasswordForm] = useState(false);

  const handleShowLoginForm = () => {
    setShowLoginForm(true);
    setShowRegisterForm(false);
    setShowChangePasswordForm(false);
  };

  const handleShowRegisterForm = () => {
    setShowLoginForm(false);
    setShowRegisterForm(true);
    setShowChangePasswordForm(false);
  };

  const handleShowChangePasswordForm = () => {
    setShowLoginForm(false);
    setShowRegisterForm(false);
    setShowChangePasswordForm(true);
  };

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Electronicos') {
              iconName = focused ? 'phone-android' : 'phone-iphone';
            } else if (route.name === 'Ropa') {
              iconName = focused ? 't-shirt' : 'shopping-bag';
            } else if (route.name === 'Hogar') {
              iconName = focused ? 'home' : 'kitchen';
            } else if (route.name === 'Deportes') {
              iconName = focused ? 'sports-soccer' : 'sports-basketball';
            }

            return <MaterialIcons name={iconName} size={size} color={color} />;
          },
        })}
        tabBarOptions={{
          activeTintColor: '#6200EE',
          inactiveTintColor: 'gray',
          style: {
            backgroundColor: '#fff',
            borderTopWidth: 1,
            borderTopColor: '#eee',
          },
          labelStyle: {
            fontSize: 14,
            fontWeight: 'bold',
          },
        }}
      >
        <Tab.Screen name="Electrónicos" component={ProductList} initialParams={{ categoria: 'Electrónicos' }} />
        <Tab.Screen name="Ropa" component={ProductList} initialParams={{ categoria: 'Ropa' }} />
        <Tab.Screen name="Hogar" component={ProductList} initialParams={{ categoria: 'Hogar' }} />
        <Tab.Screen name="Deportes" component={ProductList} initialParams={{ categoria: 'Deportes' }} />
      </Tab.Navigator>

      {!showLoginForm && !showRegisterForm && !showChangePasswordForm && (
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
          <h1>Plataforma de Comercio Electrónico</h1>
          <div style={{ marginTop: '20px' }}>
            <button style={buttonStyle} onClick={handleShowLoginForm}>Iniciar Sesión</button>
            <button style={buttonStyle} onClick={handleShowRegisterForm}>Registrarse</button>
            <button style={buttonStyle} onClick={handleShowChangePasswordForm}>Cambiar contraseña</button>
          </div>
        </div>
      )}
      {showLoginForm && (
        <div style={formContainerStyle}>
          <LoginForm />
        </div>
      )}
      {showRegisterForm && (
        <div style={formContainerStyle}>
          <RegisterForm />
        </div>
      )}
      {showChangePasswordForm && (
        <div style={formContainerStyle}>
          <ChangePasswordForm />
        </div>
      )}
    </NavigationContainer>
  );
};

const buttonStyle = {
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  padding: '10px 10px',
  margin: '0 10px',
  cursor: 'pointer',
};

const formContainerStyle = {
  width: '45%',
  margin: '20px auto',
};

export default App;
