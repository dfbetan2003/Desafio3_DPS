import React, { useState } from 'react';

const RegisterForm = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [profileImageUrl, setProfileImageUrl] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre_usuario: username,
          correo: email,
          contrasena: password,
          imagen_perfil: profileImageUrl,
        }),
      });

      const data = await response.json();
      console.log('Nuevo usuario registrado:', data);
    } catch (error) {
      console.error('Error al registrar usuario:', error);
    }
  };

  return (
    <div style={containerStyle}>
      <h2 style={headingStyle}>Registrarse</h2>
      <form onSubmit={handleSubmit} style={formStyle}>
        <div style={inputGroupStyle}>
          <label style={labelStyle}>Nombre de usuario:</label>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} style={inputStyle} />
        </div>
        <div style={inputGroupStyle}>
          <label style={labelStyle}>Correo electrónico:</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} style={inputStyle} />
        </div>
        <div style={inputGroupStyle}>
          <label style={labelStyle}>Contraseña:</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={inputStyle} />
        </div>
        <div style={inputGroupStyle}>
          <label style={labelStyle}>URL de la imagen de perfil:</label>
          <input type="text" value={profileImageUrl} onChange={(e) => setProfileImageUrl(e.target.value)} style={inputStyle} />
        </div>
        <button type="submit" style={buttonStyle}>Registrarse</button>
      </form>
    </div>
  );
};

const containerStyle = {
  width: '80%',
  margin: '20px auto',
};

const headingStyle = {
  fontSize: '24px',
  fontWeight: 'bold',
  marginBottom: '20px',
};

const formStyle = {
  display: 'flex',
  flexDirection: 'column',
};

const inputGroupStyle = {
  marginBottom: '15px',
};

const labelStyle = {
  marginBottom: '5px',
  fontSize: '16px',
};

const inputStyle = {
  width: '100%',
  padding: '10px',
  fontSize: '16px',
  border: '1px solid #ccc',
  borderRadius: '5px',
};

const buttonStyle = {
  backgroundColor: '#007bff',
  color: '#fff',
  border: 'none',
  borderRadius: '5px',
  padding: '10px 20px',
  fontSize: '16px',
  cursor: 'pointer',
};

export default RegisterForm;
