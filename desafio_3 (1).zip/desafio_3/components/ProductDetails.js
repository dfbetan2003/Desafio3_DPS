import React, { useState } from 'react';

const ProductDetails = ({ product, productId, onSave, onCancel, onDelete, onPressBack }) => {
  const [editedProduct, setEditedProduct] = useState({ ...product });
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedProduct({ ...editedProduct, [name]: value });
  };

  const handleSpecificationChange = (field, value) => {
    setEditedProduct({
      ...editedProduct,
      especificaciones: {
        ...editedProduct.especificaciones,
        [field]: value
      }
    });
  };

  const handleOptionChange = (optionType, value) => {
    setEditedProduct({
      ...editedProduct,
      opciones: {
        ...editedProduct.opciones,
        [optionType]: value
      }
    });
  };

  const handleImageChange = (index, value) => {
    const updatedImages = [...editedProduct.imagenes];
    updatedImages[index] = value;
    setEditedProduct({
      ...editedProduct,
      imagenes: updatedImages
    });
  };

  const handleDelete = async () => {
    setShowConfirmDelete(true);
  };

  const handleDeleteConfirmation = async () => {
    setShowConfirmDelete(false);
    try {
      // Aquí puedes realizar la lógica de eliminación del producto
      onDelete(productId);
      setShowSuccessMessage(true);
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(editedProduct)
      });
      if (!response.ok) {
        throw new Error('Failed to update product');
      }
      onSave(editedProduct);
      setShowSuccessMessage(true);
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  return (
    <div style={styles.detailContainer}>
      {/* Imágenes */}
      <h3>ID del producto: {productId}</h3> {/* Mostrar el ID del producto aquí */}
      <h3>Imágenes:</h3>
      <div>
        {editedProduct.imagenes.map((image, index) => (
          <div key={index} style={{ marginBottom: '10px' }}>
            <input
              type="text"
              name={`image-${index}`}
              value={image}
              onChange={(e) => handleImageChange(index, e.target.value)}
              placeholder={`URL de imagen ${index + 1}`}
              style={styles.input}
            />
          </div>
        ))}
      </div>

      {/* Nombre */}
      <input
        type="text"
        name="nombre"
        value={editedProduct.nombre}
        onChange={handleChange}
        placeholder="Nombre del producto"
        style={styles.input}
      />

      {/* Descripción */}
      <textarea
        name="descripcion"
        value={editedProduct.descripcion}
        onChange={handleChange}
        placeholder="Descripción del producto"
        style={styles.textarea}
      />

      {/* Precio */}
      <input
        type="number"
        name="precio"
        value={editedProduct.precio}
        onChange={handleChange}
        placeholder="Precio del producto"
        style={styles.input}
      />

      {/* Especificaciones */}
      <h3>Especificaciones:</h3>
      <div>
        {editedProduct.especificaciones && Object.entries(editedProduct.especificaciones).map(([key, value]) => (
          <input
            key={key}
            type="text"
            name={`especificaciones-${key}`}
            value={value || ''}
            onChange={(e) => handleSpecificationChange(key, e.target.value)}
            placeholder={key}
            style={styles.input}
          />
        ))}
      </div>

      {/* Botones de guardar, eliminar y cancelar */}
      <div style={styles.buttonContainer}>
        <button style={styles.saveButton} onClick={handleSave}>Guardar</button>
        <button style={styles.deleteButton} onClick={handleDelete}>Eliminar</button>
        <button style={styles.cancelButton} onClick={onCancel}>Cancelar</button>
        <button style={styles.backButton} onClick={onPressBack}>Volver al inicio</button>
      </div>

      
    </div>
  );
};

const styles = {
  detailContainer: {
    padding: '20px',
    borderBottom: '1px solid #ccc',
    backgroundColor: '#fff',
    borderRadius: '10px',
    marginVertical: '10px',
    boxShadow: '0px 2px 3px rgba(0, 0, 0, 0.25)',
  },
  input: {
    width: '100%',
    marginBottom: '10px',
    padding: '8px',
    fontSize: '16px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  textarea: {
    width: '100%',
    height: '100px',
    marginBottom: '10px',
    padding: '8px',
    fontSize: '16px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
  },
  deleteButton: {
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
  },
  cancelButton: {
    backgroundColor: '#ccc',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
  },
  backButton: {
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    padding: '10px 20px',
    cursor: 'pointer',
  },
  modalContainer: {
    position: 'fixed',
    zIndex: 1,
    left: 0,
    top: 0,
    width: '100%',
    height: '100%',
    overflow: 'auto',
    backgroundColor: 'rgba(0,0,0,0.4)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fefefe',
    padding: '20px',
    borderRadius: '5px',
    maxWidth: '400px',
    textAlign: 'center',
  },
  successMessage: {
    position: 'fixed',
    zIndex: 1,
    left: '50%',
    bottom: '20px',
    transform: 'translateX(-50%)',
    backgroundColor: '#4CAF50',
    color: 'white',
    padding: '15px',
    borderRadius: '5px',
    textAlign: 'center',
  },
};

export default ProductDetails;
