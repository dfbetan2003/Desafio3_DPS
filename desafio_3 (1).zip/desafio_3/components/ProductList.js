import React, { useState, useEffect } from 'react';
import { View, FlatList, Button } from 'react-native';
import Product from './Product';
import ProductDetails from './ProductDetails';
import SearchBar from './SearchBar';
import AddProductForm from './AddProductForm';

const ProductList = ({ navigation, route }) => {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const { categoria } = route.params;
  

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos?categoria=${categoria}`);
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchProducts();
  }, [categoria]);

  const searchProducts = async (term) => {
    try {
      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos?nombre=${term.toLowerCase()}`);
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Error searching products:', error);
    }
  };

  const showDetails = (product) => {
    setSelectedProduct(product);
  };

  const backToProducts = async () => {
    setSelectedProduct(null);
    const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos?categoria=${categoria}`);
    const data = await response.json();
    setProducts(data);
  };

  const addProduct = async (newProduct) => {
    try {
      const response = await fetch('https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newProduct),
      });
      if (response.ok) {
        const data = await response.json();
        setProducts([...products, data]);
        setShowAddForm(false);
      } else {
        throw new Error('Failed to add product');
      }
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  const renderProduct = ({ item }) => {
    if (!item) return null;
    return <Product product={item} onPress={() => showDetails(item)} />;
  };

  return (
    <View>
      <SearchBar onSearch={searchProducts} />
      {showAddForm ? (
        <AddProductForm onAdd={addProduct} />
      ) : (
        <>
          <Button title="Agregar producto" onPress={() => setShowAddForm(true)} />
          {selectedProduct ? (
            <ProductDetails
              product={selectedProduct}
              productId={selectedProduct.id} // Pasar el ID del producto seleccionado
              onPressBack={backToProducts}
            />
          ) : (
            <FlatList
              data={products}
              renderItem={renderProduct}
              keyExtractor={(item) => item?.id?.toString()}
            />
          )}
        </>
      )}
    </View>
  );
};

export default ProductList;
