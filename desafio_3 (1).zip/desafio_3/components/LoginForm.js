import React, { useState } from 'react';
import { View, Text, TextInput, Button, TouchableOpacity, StyleSheet, Image } from 'react-native';
import App1 from './App1';

const LoginForm = ({navigation}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [profilePicture, setProfilePicture] = useState('');
  const [newProfilePicture, setNewProfilePicture] = useState('');

  const handleSubmit = async () => {
    try {
      const response = await fetch('https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios', {
        method: 'GET',
      });
      const users = await response.json();
      const user = users.find((u) => u.correo === email && u.contrasena === password);
      if (user) {
        console.log('Inicio de sesión exitoso:', user);
        setLoggedInUser(user);
        setError('');
        setEmail(''); // Limpiar el campo de correo electrónico después del inicio de sesión exitoso

        // Verificar si el usuario tiene una imagen de perfil y configurarla
        if (user.profilePicture) {
          setProfilePicture(user.profilePicture);
        }
      } else {
        console.error('Credenciales incorrectas');
        setError('Credenciales incorrectas');
      }
    } catch (error) {
      console.error('Error al iniciar sesión:', error);
      setError('Error al iniciar sesión. Por favor, intenta nuevamente.');
    }
  };

  const handleChangePassword = async () => {
    try {
      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios/${loggedInUser.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contrasena: newPassword,
        }),
      });

      if (response.ok) {
        setSuccessMessage('Contraseña cambiada exitosamente.');
        setNewPassword(''); // Limpiar el campo de nueva contraseña después del cambio exitoso
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error al cambiar la contraseña.');
      }
    } catch (error) {
      console.error('Error al cambiar contraseña:', error);
      setError(error.message || 'Error al cambiar la contraseña. Por favor, intenta nuevamente.');
    }
  };

  const handleChangeProfilePicture = async () => {
    try {
      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios/${loggedInUser.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          profilePicture: newProfilePicture,
        }),
      });

      if (response.ok) {
        setSuccessMessage('Foto de perfil cambiada exitosamente.');
        setProfilePicture(newProfilePicture); // Actualizar la foto de perfil mostrada
        setNewProfilePicture(''); // Limpiar el campo de nueva foto de perfil
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error al cambiar la foto de perfil.');
      }
    } catch (error) {
      console.error('Error al cambiar la foto de perfil:', error);
      setError(error.message || 'Error al cambiar la foto de perfil. Por favor, intenta nuevamente.');
    }
  };

  return (
    <View>
      <Text style={styles.heading}>Iniciar Sesión</Text>
      {loggedInUser ? (
        <View>
          <Text style={styles.welcome}>Hola, bienvenido {loggedInUser.nombre_usuario}!</Text>
          {profilePicture ? (
            <Image source={{ uri: profilePicture }} style={styles.profilePicture} />
          ) : null}

          <TouchableOpacity onPress={handleChangeProfilePicture}>
            <Text style={styles.link}>Cambiar foto de perfil</Text>
          </TouchableOpacity>
          <TextInput
            style={styles.input}
            value={newProfilePicture}
            onChangeText={(text) => setNewProfilePicture(text)}
            placeholder="URL de la nueva foto de perfil"
          />
          <Button title="Guardar Cambios" onPress={handleChangeProfilePicture} />
          <TextInput
            style={styles.input}
            value={newPassword}
            onChangeText={(text) => setNewPassword(text)}
            placeholder="Nueva contraseña"
            secureTextEntry={true}
          />
          <Button title="Cambiar Contraseña" onPress={handleChangePassword} />
          {successMessage ? <Text style={styles.success}>{successMessage}</Text> : null}
          {error ? <Text style={styles.error}>{error}</Text> : null}

          
        
        </View>
      ) : (
        <View>
          <Text>Correo electrónico:</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={(text) => setEmail(text)}
            keyboardType="email-address"
          />
          <Text>Contraseña:</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={(text) => setPassword(text)}
            secureTextEntry={true}
          />
          <Button title="Iniciar Sesión" onPress={handleSubmit} />
          <TouchableOpacity onPress={() => console.log("Enlace para restablecer la contraseña")}>
            <Text style={styles.link}>¿Olvidaste tu contraseña?</Text>
          </TouchableOpacity>
          {error ? <Text style={styles.error}>{error}</Text> : null}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  welcome: {
    fontSize: 18,
    marginBottom: 10,
  },
  profilePicture: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  profilePictureContainer: {
    alignItems: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
  },
  error: {
    color: 'red',
    marginTop: 10,
  },
  success: {
    color: 'green',
    marginTop: 10,
  },
  link: {
    color: 'blue',
    textDecorationLine: 'underline',
    marginTop: 10,
  },
});

export default LoginForm;
