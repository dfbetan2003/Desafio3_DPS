import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const ChangePasswordForm = () => {
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleChangePassword = async () => {
    try {
      if (!email) {
        setError('Por favor, ingresa tu correo electrónico.');
        return;
      }

      if (newPassword !== confirmPassword) {
        setError('Las contraseñas no coinciden.');
        return;
      }

      const response = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios?correo=${email}`, {
        method: 'GET',
      });

      if (response.ok) {
        const userData = await response.json();
        if (userData.length === 0) {
          throw new Error('Usuario no encontrado.');
        }
        const userId = userData[0].id;
        
        const changePasswordResponse = await fetch(`https://660f73af356b87a55c5168c5.mockapi.io/desafio/Usuarios/${userId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contrasena: newPassword,
          }),
        });

        if (changePasswordResponse.ok) {
          setSuccessMessage('Contraseña cambiada exitosamente.');
          setNewPassword('');
          setConfirmPassword('');
          setError('');
        } else {
          const errorData = await changePasswordResponse.json();
          throw new Error(errorData.message || 'Error al cambiar la contraseña.');
        }
      } else {
        throw new Error('Error al buscar usuario.');
      }
    } catch (error) {
      console.error('Error al cambiar contraseña:', error);
      setError(error.message || 'Error al cambiar la contraseña. Por favor, intenta nuevamente.');
    }
  };

  return (
    <View>
      <Text style={styles.heading}>Cambiar Contraseña</Text>
      <Text>Ingresa tu correo electrónico:</Text>
      <TextInput
        style={styles.input}
        value={email}
        onChangeText={(text) => setEmail(text)}
        placeholder="Correo electrónico"
        keyboardType="email-address"
      />
      <Text>Ingresa tu nueva contraseña:</Text>
      <TextInput
        style={styles.input}
        value={newPassword}
        onChangeText={(text) => setNewPassword(text)}
        placeholder="Nueva contraseña"
        secureTextEntry={true}
      />
      <Text>Confirma tu nueva contraseña:</Text>
      <TextInput
        style={styles.input}
        value={confirmPassword}
        onChangeText={(text) => setConfirmPassword(text)}
        placeholder="Confirmar contraseña"
        secureTextEntry={true}
      />
      <Button title="Cambiar Contraseña" onPress={handleChangePassword} />
      {successMessage ? <Text style={styles.success}>{successMessage}</Text> : null}
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
  },
  error: {
    color: 'red',
    marginTop: 10,
  },
  success: {
    color: 'green',
    marginTop: 10,
  },
});

export default ChangePasswordForm;
