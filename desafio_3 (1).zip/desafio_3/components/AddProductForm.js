import React, { useState } from 'react';
import { View, TextInput, Button, Picker } from 'react-native';

const AddProductForm = ({ onAddProduct }) => {
  const [nombre, setNombre] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [precio, setPrecio] = useState('');
  const [categoria, setCategoria] = useState('');
  const [especificaciones, setEspecificaciones] = useState(['']);

  const handleAddProduct = async () => {
    try {
      const response = await fetch('https://660f73af356b87a55c5168c5.mockapi.io/desafio/Productos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre,
          descripcion,
          precio: parseFloat(precio),
          categoria,
          especificaciones,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to add product');
      }

      // Obtener el nuevo producto creado desde la respuesta de la API
      const newProduct = await response.json();

      // Llamar a la función para agregar el nuevo producto
      onAddProduct(newProduct);

      // Limpiar los campos del formulario
      setNombre('');
      setDescripcion('');
      setPrecio('');
      setCategoria('');
      setEspecificaciones(['']);
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  const handleAddSpecification = () => {
    setEspecificaciones([...especificaciones, '']);
  };

  const handleSpecificationChange = (index, value) => {
    const updatedEspecificaciones = [...especificaciones];
    updatedEspecificaciones[index] = value;
    setEspecificaciones(updatedEspecificaciones);
  };

  return (
    <View>
      <TextInput
        value={nombre}
        onChangeText={setNombre}
        placeholder="Nombre del producto"
      />
      <TextInput
        value={descripcion}
        onChangeText={setDescripcion}
        placeholder="Descripción del producto"
      />
      <TextInput
        value={precio}
        onChangeText={setPrecio}
        placeholder="Precio del producto"
        keyboardType="numeric"
      />
      <Picker
        selectedValue={categoria}
        onValueChange={(itemValue, itemIndex) => setCategoria(itemValue)}
      >
        <Picker.Item label="Seleccionar categoría" value="" />
        <Picker.Item label="Electrónicos" value="Electrónicos" />
        <Picker.Item label="Ropa" value="Ropa" />
        <Picker.Item label="Hogar" value="Hogar" />
        <Picker.Item label="Deportes" value="Deportes" />
      </Picker>
      {especificaciones.map((especificacion, index) => (
        <TextInput
          key={index}
          value={especificacion}
          onChangeText={(text) => handleSpecificationChange(index, text)}
          placeholder={`Especificación ${index + 1}`}
        />
      ))}
      <Button
        title="Agregar Especificación"
        onPress={handleAddSpecification}
      />
      <Button
        title="Agregar Producto"
        onPress={handleAddProduct}
      />
    </View>
  );
};

export default AddProductForm;
